import os
import re
import io
import html
import base64
import traceback
import requests
import glob
from contextlib import redirect_stdout
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class BloClawCoordinator:
    def __init__(self):
        self.api_key = os.getenv("DOUBAO_API_KEY")
        self.base_url = "https://ark.cn-beijing.volces.com/api/v3"
        self.model_name = os.getenv("DOUBAO_ENDPOINT", "ep-20250222165018-9xts8")
        if not self.api_key:
            self.api_key = os.getenv("OPENAI_API_KEY", "")
            self.base_url = "https://api.openai.com/v1"
            self.model_name = "gpt-3.5-turbo"
        self.client = OpenAI(api_key=self.api_key, base_url=self.base_url)

    def clean_code(self, raw_code):
        if not raw_code: return ""
        code = raw_code.strip()
        if code.startswith("```"):
            code = re.sub(r"^```[a-zA-Z]*\n?", "", code)
            code = re.sub(r"\n?```$", "", code).strip()
        return code

    def extract_tag(self, text, tag):
        pattern = f"<{tag}>(.*?)</{tag}>"
        match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
        return match.group(1).strip() if match else ""

    def execute_sandbox(self, python_code):
        output_buffer = io.StringIO()
        old_pngs = set(glob.glob("*.png") + glob.glob("*.jpg"))
        
        success = True; error_msg = ""
        try:
            with redirect_stdout(output_buffer):
                injection_header = "import matplotlib.pyplot as plt\nimport warnings\nwarnings.filterwarnings('ignore')\nplt.rcParams['figure.figsize'] = (10, 6)\nplt.rcParams['figure.dpi'] = 150\n"
                safe_code = re.sub(r"plt\.show\(\)", "", python_code)
                # 剔除可能引发系统崩溃的所有 pip 请求！
                safe_code = re.sub(r"^\s*[!%]pip.*\n?", "", safe_code, flags=re.MULTILINE)
                safe_code = re.sub(r"^\s*os\.system\(['\"]pip.*['\"]\).*\n?", "", safe_code, flags=re.MULTILINE)
                exec(injection_header + safe_code, {"requests": requests, "os": os, "re": re})
        except Exception as e:
            success = False; error_msg = traceback.format_exc()
            
        new_pngs = list(set(glob.glob("*.png") + glob.glob("*.jpg")) - old_pngs)
        actual_plot_file = os.path.abspath(new_pngs[0]) if new_pngs else None

        return {"success": success, "stdout": output_buffer.getvalue().strip(), "error": error_msg, "plot_path": actual_plot_file}

    def generate_rdkit_2d_html(self, raw_target):
        try:
            from rdkit import Chem; from rdkit.Chem import Draw
            pure_smiles = max(re.findall(r'[A-Za-z0-9@+\-\[\]\.\(\)\=\#\/\\]{4,}', raw_target), key=len)
            if pure_smiles.endswith("OH"): pure_smiles = pure_smiles[:-1] 
            mol = Chem.MolFromSmiles(pure_smiles)
            if not mol: return None
            path = os.path.abspath("temp_mol.png")
            Draw.MolToFile(mol, path, size=(800, 600))
            with open(path, "rb") as f: b64 = base64.b64encode(f.read()).decode('utf-8')
            return f"<div style='height:100%; display:flex; align-items:center; justify-content:center; background:#fafafa;'><img src='data:image/png;base64,{b64}' style='max-width:98%; max-height:98%; border-radius:12px; box-shadow:0 6px 25px rgba(0,0,0,0.08); border:1px solid #e5e7eb; background:white; padding:10px;'></div>"
        except: return None

    def generate_3d_iframe(self, core_data, is_custom=False, pdb_str=None):
        if not is_custom:
            pdb = re.sub(r'[^a-zA-Z0-9]', '', core_data).lower()
            return f"<iframe src='https://3dmol.csb.pitt.edu/viewer.html?pdb={pdb}&style=cartoon;color:spectrum&spin=true&bcolor=ffffff' width='100%' height='100%' style='border:none;'></iframe>"
        else:
            escaped_pdb = pdb_str.replace("`", "")
            script = f"var v = $3Dmol.createViewer('g', {{backgroundColor:'#ffffff'}}); v.addModel(`{escaped_pdb}`, 'pdb'); v.setStyle({{}}, {{cartoon:{{color:'spectrum'}}}}); v.zoomTo(); v.render();"
            html_src = f"<html><head><script src='https://3Dmol.csb.pitt.edu/build/3Dmol-min.js'></script></head><body style='margin:0;'><div id='g' style='width:100vw; height:100vh;'></div><script>{script}</script></body></html>"
            return f"<iframe srcdoc='{html.escape(html_src)}' width='100%' height='100%' style='border:none;'></iframe>"

    def process_chat(self, user_message, uploaded_files=None, memory_context=None):
        file_context = ""
        if uploaded_files:
            file_context += "\n\n【后台已载入文档，请随时提取】\n"
            for f in uploaded_files:
                path = f if isinstance(f, str) else getattr(f, 'filepath', getattr(f, 'name', str(f)))
                ext = os.path.splitext(path)[1].lower()
                try:
                    if ext == '.pdf':
                        import PyPDF2
                        with open(path, 'rb') as pf: file_context += f"📰 [医学摘要]:\n{''.join([p.extract_text() for p in PyPDF2.PdfReader(pf).pages[:6]])[:3000]}\n"
                    elif ext in ['.xlsx', '.xls']:
                        import pandas as pd
                        df = pd.read_excel(path); heads = ", ".join(df.columns.tolist())
                        file_context += f"📊 [Excel概览]: 包含列({heads}), 前5行数据:\n{df.head(5).to_string()}\n"
                    elif ext in ['.txt', '.csv', '.md']:
                        with open(path, 'r', encoding='utf-8') as tf: file_context += f"📄 [资料提取]:\n{tf.read()[:3000]}\n"
                except: pass
        
        # 🌟 最变态的防弹修改！在用户每说完一句话后，向它的脑子里打入强制印记！
        enforcement_reminder = "\n\n(📝 回复必选一：1. TEXT  2. PYTHON_SANDBOX  3. 2D_MOLECULE  4. 3D_PROTEIN  5. FOLD_PROTEIN。请【必定】使用 <thought><action><target><reply> 的格式框住每一部分的作答！不要输出其他格式！)"
        
        final_prompt = str(user_message) + file_context + enforcement_reminder

        sys_prompt = """你是一个冷静的 AI 科研运算中枢。
【执行法则】每一句交流你都必须输出四个完整的标签：
<thought>写下你对刚刚问题的思考和动作选用理由</thought>
<action>必须大写填写: TEXT / PYTHON_SANDBOX / 2D_MOLECULE / 3D_PROTEIN / FOLD_PROTEIN 之一</action>
<target>如果是写代码、算分子结构或查3D，必须在这里写下对应的 Python代码 / SMILES序列 / PDB编号 等参数。如果你选了 TEXT，则留空！</target>
<reply>写下你极其专业的分析与解答并用Markdown分段。</reply>"""

        llm_messages = [{"role": "system", "content": sys_prompt}]
        
        if memory_context:
            for msg_dict in memory_context[-6:]:  
                r = msg_dict.get("role", "")
                c = str(msg_dict.get("content", ""))
                
                if not isinstance(c, str): continue
                if r == "assistant":
                    c = re.sub(r"!\[.*?\]\(.*?\)", "", c)
                    c = re.sub(r"\*\(\*\*🧠.*?\)\*\n\n", "", c)
                    llm_messages.append({"role": "assistant", "content": c[:800]})
                elif r == "user":
                    clean_user = re.sub(r"\n\n\*\(\w+ .*\)\*", "", c)
                    llm_messages.append({"role": "user", "content": clean_user})

        llm_messages.append({"role": "user", "content": final_prompt})

        try:
            resp = self.client.chat.completions.create(model=self.model_name, messages=llm_messages, temperature=0.1)
            raw_text = resp.choices[0].message.content
            
            # 🌟 兼容大模型抽风忘写大小写或者被 Markdown 污染！
            action_val = self.extract_tag(raw_text, "action").upper().strip()
            # 如果它瞎写标签导致我们没切中，保底恢复机制介入
            if not action_val:
                action = "TEXT"
                reply_md = raw_text # 它没写标签，说明把所有内容当了白话文输出！全部捞给显示层
                thought = "分析意图并解答。"
                core_data = ""
            else:
                action = action_val
                core_data = self.clean_code(self.extract_tag(raw_text, "target"))
                thought = self.extract_tag(raw_text, "thought")
                reply_md = self.extract_tag(raw_text, "reply")
                
                if not reply_md: reply_md = "任务输出结果已载入视图。"
                if not thought: thought = "推演指令中..."

            final_md = f"*(**🧠 分析主盘**: {thought})*\n\n{reply_md}"
            screen_html = None  

            if action == "PYTHON_SANDBOX" and core_data:
                res = self.execute_sandbox(core_data)
                if res['success']:
                    if res['stdout']: final_md += f"\n\n---\n**🤖 执行终端反馈**:\n```text\n{res['stdout']}\n```"
                    if res['plot_path']: 
                        with open(res['plot_path'], "rb") as f: b64 = base64.b64encode(f.read()).decode('utf-8')
                        screen_html = f"<div style='width:100%; height:100%; display:flex; align-items:center; justify-content:center; background:#fafafa;'><img src='data:image/png;base64,{b64}' style='max-width:98%; max-height:98%; border-radius:12px; box-shadow:0 6px 25px rgba(0,0,0,0.08); border:1px solid #e5e7eb; background:white; padding:10px;'></div>"
                else: 
                     final_md += f"\n\n*(❌ 代码崩溃反馈)*\n```python-traceback\n{res['error']}\n```"

            elif action == "2D_MOLECULE" and core_data: screen_html = self.generate_rdkit_2d_html(core_data)
            elif action == "3D_PROTEIN" and core_data: screen_html = self.generate_3d_iframe(core_data)
            elif action == "FOLD_PROTEIN" and core_data:
                seq = re.sub(r'[^A-Z]', '', core_data.upper())
                api_resp = requests.post('https://api.esmatlas.com/foldSequence/v1/pdb/', data=seq, timeout=40)
                if api_resp.status_code == 200:
                    screen_html = self.generate_3d_iframe(None, is_custom=True, pdb_str=api_resp.text)
                    final_md += "\n\n🟢 **宇宙力场测算结束，折叠构象实体已导入全息视窗。**"

            return {"text": final_md, "screen_html": screen_html}
            
        except Exception as e: return {"text": str(e), "screen_html": None}
